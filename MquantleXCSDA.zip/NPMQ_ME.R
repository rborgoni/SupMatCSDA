
NPMQ_ME<-function(Y.n,X.e,X.add,lon,lat, k.x, k.mq,
                  theta=2,quantile,c=1.345,tol=0.0001,maxit=100)
{
  #X.e: error-prone variable
  #X.add: matrix of additional covariates
  #k.x: knots for measurement correction model
  #k.mq: knots for NPMQ
  #b= intial values
  #theta: smoothing parameter
  
  kx=k.x
  ky=k.mq

    my.default.knots.2D<-function (x1, x2, num.knots) 
  {
    require("cluster")
    if (missing(num.knots)) 
      num.knots <- max(10, min(50, round(length(x1)/4)))
    X <- cbind(x1, x2)
    dup.inds <- (1:nrow(X))[dup.matrix(X) == T]
    if (length(dup.inds) > 0) 
      X <- X[-dup.inds, ]
    knots <- clara(X, num.knots)$medoids
    return(knots)
  }

      Ztps <- function(x,knots)
  {
    numKnots <- nrow(knots)
    dist.mat <- matrix(0,numKnots,numKnots)
    dist.mat[lower.tri(dist.mat)] <- dist(as.matrix(knots))
    dist.mat <- dist.mat + t(dist.mat)
    Omega <- tps.cov(dist.mat,d=2)
    x.knot.diffs.1 <- outer(x[,1],knots[,1],"-")
    x.knot.diffs.2 <- outer(x[,2],knots[,2],"-")
    x.knot.dists <- sqrt(x.knot.diffs.1^2+x.knot.diffs.2^2)
    prelim.Z <- tps.cov(x.knot.dists,m=2,d=2)
    sqrt.Omega <- matrix.sqrt(Omega)
    Z <- t(solve(sqrt.Omega,t(prelim.Z)))
    output<-list(basis=prelim.Z, penalty=Omega ,Z=Z)
    return(output)
  }

    gcv.delta2<-function(nsamp,Z,B2,BTB.2, D2, delta.2)
  {
    Lambda.2.inv<-1/nsamp*BTB.2+delta.2*D2
    eigen.decomp.Lambda.2 <- eigen(Lambda.2.inv)
    eigen.Lamdba.2.mat <- cbind(eigen.decomp.Lambda.2$vectors)
    eigen.Lambda.2.vec <- eigen.decomp.Lambda.2$val
    Lambda.2<-eigen.Lamdba.2.mat%*%diag(1/eigen.Lambda.2.vec)%*%
      t(eigen.Lamdba.2.mat)
    theta.2.Hat<-1/nsamp*Lambda.2%*%(t(B2)%*%Z)
    RSS.delta2<-t(Z-B2%*%theta.2.Hat)%*%(Z-B2%*%theta.2.Hat)
    smooth.delta2<-1/nsamp*B2%*%Lambda.2%*%t(B2)
    gcv.delta2<-1/nsamp*
      as.vector(RSS.delta2)/(1-1/nsamp*sum(diag(smooth.delta2)))^2
    gcv.delta2
  }
  

  lon<-(lon-min(lon))/(max(lon)-min(lon))
  lat<-(lat-min(lat))/(max(lat)-min(lat))
  
  n=length(Y.n)
  nsamp=n
  q.x<-k.x+3
  knots2<-my.default.knots.2D(lon,lat,k.x) 
  Z2<-Ztps(cbind(lon,lat),knots2)$basis
  B2<-cbind(1,lon,lat,Z2)
  BTB.2 <- crossprod(B2,B2)
  D2<-matrix(0,q.x,q.x)
  D2[4:q.x,4:q.x]<-Ztps(cbind(lon,lat),knots2)$penalty

  delta.range<-seq(-11, 11, length.out =60)
  V<-rep(0,60)
  for (i in 1:60){
    V[i]<-gcv.delta2(nsamp=n,Z=X.e,B2,BTB.2, D2,10^(delta.range[i]))}
  index.delta2<-(1:60)[V==min(V)]
  delta.2<-10^delta.range[index.delta2]
  Lambda.2.inv<-1/n*BTB.2+delta.2*D2
  eigen.decomp.Lambda.2 <- eigen(Lambda.2.inv)
  eigen.Lamdba.2.mat <- cbind(eigen.decomp.Lambda.2$vectors) #eigenvectors
  eigen.Lambda.2.vec <- eigen.decomp.Lambda.2$val #eigenvalues
  Lambda.2<-eigen.Lamdba.2.mat%*%diag(1/eigen.Lambda.2.vec)%*%t(eigen.Lamdba.2.mat)
  theta.2.Hat<-1/n*Lambda.2%*%(t(B2)%*%X.e)
  
  W.hat<-B2%*%theta.2.Hat 
  
  knots<-my.default.knots.2D(lon,lat,k.mq)
  Z<-Ztps(cbind(lon,lat),knots)$basis
  B1<-cbind(1,lon,lat,Z)
  BTB.1 <- crossprod(B1,B1)
  X.n<-cbind(1,W.hat, X.add,lon,lat,Z)
  
  p1<-dim(X.add)[2]+4
  p2<-nrow(knots)                   
  p<-p1+p2 
  
  G<-matrix(0,p,p)
  G[(p1+1):p,(p1+1):p]<-Ztps(cbind(lon,lat),knots)$penalty
  
  D1<-matrix(0,(p2+3),(p2+3))
  D1[4:(p2+3),4:(p2+3)]<-Ztps(cbind(lon,lat),knots)$penalty 
  
  
  quant=quantile
  nq<-length(quant)
  b<-matrix(0,p,1)
    
  my.psi.huber<-function(u,c){
    u*(u>=-c)*(u<=c)+c*sign(u)}
  my.psi.q<-function(u,q){
    s<-median(abs(u))/0.6745
    c<-c
    w <- psi.huber((u/s),c)
    ww <- 2 * (1 - q) * w
    ww[u> 0] <- 2 * q * w[u > 0]
    w <- ww
    w*u
    
  }
  
  my.b<-function(X,Y,W,G,lambda)
  {
    solve(t(X)%*%W%*%X+lambda*G)%*%t(X)%*%W%*%Y
  }
  
  stima<-function(l){
    n<-nrow(X.n)
    diff<-1
    iter<-0
    while (diff>tol)
    {
      iter<-iter+1
      res<-Y.n-X.n%*%b 
      W.n<-diag(c(my.psi.q(res,qtl)/res),n)
      assign("W.n", W.n, pos=1)
      b.ott<-my.b(X.n,Y.n,W.n,G,l)
      diff<-sum((b-b.ott)^2)
      b<-b.ott
      if (iter>maxit)
      {warning(paste("failed to converge in", maxit, "steps at q = ", qtl))
        break}
    }
    y.hat=X.n%*%b
    list(fitted.values=y.hat,coef=b,we=diag(W.n))
  }
  
  my.GCV<-function(l)
  {
    tmp<-stima(l)
    y.hat<-tmp$fitted.values
    S<-(X.n)%*%solve(t(X.n)%*%W.n%*%X.n+l*G)%*%t(X.n)%*%W.n
    sum((Y.n-y.hat)^2)/((1-theta*sum(diag(S))/n)^2)
  }
  
  assign("b",b,pos=1)
  assign("tol",tol,pos=1)
  assign("maxit",maxit,pos=1)
  length.q<-length(quantile)
  y.fit<-matrix(0,n,length.q)
  y.coef<-matrix(0,p,length.q)
  y.weight<-matrix(0,n,length.q)
  l.q<-matrix(0,1,length.q)
  for (k in 1:length.q)
  {
    qtl<-quantile[k]
    qtl<-assign("qtl",qtl,pos=1)
    tmp<-optimize(my.GCV,c(5,1000))
    l.ott<-tmp$minimum
    y.stim<-stima(l.ott)
    y.fit[,k]<-y.stim$fitted.values
    y.coef[,k]=y.stim$coef
    y.weight[,k]=y.stim$we
    l.q[,k]<-l.ott
  }

  delta.1<-as.numeric(l.q)
  Lambda.1.inv<-1/nsamp*BTB.1+delta.1*D1
  eigen.decomp.Lambda.1 <- eigen(Lambda.1.inv)
  eigen.Lamdba.1.mat <- cbind(eigen.decomp.Lambda.1$vectors)
  eigen.Lambda.1.vec <- eigen.decomp.Lambda.1$val
  Lambda.1<-eigen.Lamdba.1.mat%*%diag(1/eigen.Lambda.1.vec)%*%
    t(eigen.Lamdba.1.mat)
  
  
  theta.2.Hat<-1/nsamp*Lambda.2%*%(t(B2)%*%X.e)
  Vn<-1/nsamp*Lambda.1%*%(t(B1)%*%Y.n)
  Rn<-1/nsamp*Lambda.1%*%crossprod(B1,B2)
  Tn<-1/nsamp*BTB.2
  Cn<-(Tn-t(Rn)%*%Lambda.1.inv%*%Rn)
  denominator<-t(theta.2.Hat)%*%Cn%*%theta.2.Hat
  
  
  Rn<-1/nsamp*Lambda.1%*%crossprod(B1,B2)
  b1.hat.basis<-y.coef[2]
  pos.add<-dim(X.add)[2]+2 
  theta.1.Hat<-y.coef[-c(1,3:pos.add)]
  An<-(1/nsamp)*t(B2%*%theta.2.Hat*as.vector(b1.hat.basis)+
                    B1%*%theta.1.Hat)%*%(B2-B1%*%Rn)
  Fn<-2*B2%*%Lambda.2%*%Cn%*%theta.2.Hat
  
  Dn<-(B2-B1%*%Rn)%*%theta.2.Hat
  
  Hn<-t(An%*%Lambda.2%*%t(B2)/as.vector(denominator))-
    as.vector(An%*%theta.2.Hat)*Fn/(as.vector(denominator))^2
  
  
  RSS.Z<-t(X.e-B2%*%theta.2.Hat)%*%(X.e-B2%*%theta.2.Hat)
  smooth.delta2<-1/nsamp*B2%*%Lambda.2%*%t(B2)
  
  Gn<-Dn/(as.vector(denominator))
  
  S.mq<-(X.n)%*%solve(t(X.n)%*%W.n%*%X.n+delta.1*G)%*%t(X.n)%*%W.n
  
  
  sigma.u.est<-as.vector(RSS.Z)/(nsamp-2*sum(diag(smooth.delta2))+
                                   sum(diag(smooth.delta2%*%t(smooth.delta2))))
  
  s2u<-sigma.u.est*t(Hn)%*%Hn
  
  res_q<-Y.n-X.n%*%y.coef 
  qtl<-quantile
  qtl<-assign("qtl",qtl,pos=1)
  psi<-my.psi.q(res_q,qtl)
  
  WW<- c(my.psi.q(res_q,qtl)/res_q)
  part1<-t(X.n)%*%diag(c(WW),n)%*%X.n +delta.1*G
  part2<-t(X.n)%*%diag(c(WW),n)%*%X.n
  sigma.e<-median(abs(res_q))/0.6745
  
  var.beta<-solve(part1)%*%(part2)%*%solve(part1)*(sigma.e^2)
  
  v.beta=diag(var.beta)
  
  v.beta.x= v.beta[1:pos.add]
  
  v.beta.x[2] = v.beta[2] + (s2u/n^2)
  
  b.stim=y.coef[1:pos.add,]  
  
  sd.x<-sqrt(v.beta.x)
  
  zd<- as.matrix(b.stim/(sd.x))
  sig<-matrix(0,length(zd),1)
  
  

  for (oo in 1:length(zd)){
      {if (zd[oo,1]>0) sig[oo,1]<-(1-pnorm(zd[oo,1]))*2
      else sig[oo,1]<-(pnorm(zd[oo,1]))*2}}
  
  
  
  
  list(hat.values=y.fit,
       Result1=data.frame(beta=b.stim, 
                          SD=sd.x, 
                          pvalue=sig), 
       Result2=data.frame(beta=y.coef[(ncol(X.n)-ky-1):ncol(X.n),])
      )
  
  
  
}
