######### Code #################################################################
#
#
#   Filename  :	Example.R
#
#   Project   : Semiparametric M-quantile regression with measurement error in 
#               spatial covariates: an application to housing price modelling.
#
#   R Version : R version 4.0.2 (2020-06-22)
#
#   Description: This file applies the SPMQ ME model on a subset of data using
#                in the paper             
################################################################################

rm(list = ls())
require(SemiPar)
require(MASS)

# Load the subset (300 observations) of Housing market data
# The outcome variable is: value
data.s <- read.table("Housing_market_data_sample.csv", sep=",", header=T)

# Load the function to fit the model
source("NPMQ_ME.R")

# Define the matrix of covariates
X.add<-cbind(data.s$floor,data.s$lif, data.s$heating, data.s$parking,
             data.s$bath, data.s$areatot1, data.s$areatot2,
             data.s$aband.area, data.s$univ, data.s$metro)

# SPMQ ME model at q=0.5
npmq3_q50<-NPMQ_ME(Y.n=data.s$value ,X.e=data.s$cult.cat,
                   X.add=X.add,
                   lon=data.s$lon,lat=data.s$lat,
                   k.x=50, k.mq=40,
                   theta=3,quantile=0.5,c=1.345)
npmq3_q50$Result1
